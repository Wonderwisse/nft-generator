# certificate_generator
Create a Certificate Generator Website in JavaScript
